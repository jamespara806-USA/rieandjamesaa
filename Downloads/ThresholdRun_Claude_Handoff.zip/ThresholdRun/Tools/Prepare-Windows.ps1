param(
    [Parameter(Mandatory=$true)][string]$EngineRoot,
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot),
    [ValidateRange(1,32)][int]$MaxParallelActions = 8
)
. "$PSScriptRoot\Windows.Common.ps1"
$paths = Get-ThresholdPaths $EngineRoot $ProjectRoot
$build = Join-Path $paths.Engine 'Engine\Build\BatchFiles\Build.bat'
& $build ThresholdRunEditor Win64 Development "-Project=$($paths.UProject)" `
    -WaitMutex -NoHotReloadFromIDE "-MaxParallelActions=$MaxParallelActions"
if ($LASTEXITCODE -ne 0) { throw "Editor build failed with code $LASTEXITCODE" }

$runRoot = Join-Path $paths.Project ('Saved\Automation\Map-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $runRoot | Out-Null
$receipt = Join-Path $runRoot 'prepared.json'
$previousReceipt = [Environment]::GetEnvironmentVariable('THRESHOLD_MAP_RECEIPT', 'Process')
try {
    $env:THRESHOLD_MAP_RECEIPT = $receipt
    Invoke-ThresholdProcess -FilePath (Join-Path $paths.Engine 'Engine\Binaries\Win64\UnrealEditor-Cmd.exe') `
        -TimeoutSeconds 600 -Arguments @(
            $paths.UProject, '-unattended', '-nop4', '-nosplash', '-NullRHI',
            '-EnablePlugins=PythonScriptPlugin',
            "-ExecutePythonScript=$PSScriptRoot\Create-GreyboxMap.py",
            "-abslog=$runRoot\MapPreparation.log"
        )
} finally {
    [Environment]::SetEnvironmentVariable('THRESHOLD_MAP_RECEIPT', $previousReceipt, 'Process')
}
if (!(Test-Path -LiteralPath $receipt)) { throw "Map preparation failed. Inspect $runRoot\MapPreparation.log" }
$prepared = Get-Content -Raw -LiteralPath $receipt | ConvertFrom-Json
if ($prepared.status -ne 'prepared') { throw 'Unexpected map preparation result' }
Write-Host "Editor compiled; L_Greybox saved/validated. Evidence: $runRoot"

param(
    [Parameter(Mandatory=$true)][string]$EngineRoot,
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)
. "$PSScriptRoot\Windows.Common.ps1"
$paths = Get-ThresholdPaths $EngineRoot $ProjectRoot
$map = Join-Path $paths.Project 'Content\Maps\L_Greybox.umap'
if (!(Test-Path -LiteralPath $map)) { throw 'Missing L_Greybox.umap. Run Tools\Prepare-Windows.ps1 first.' }
$output = Join-Path $paths.Project 'Builds\Windows'
if (Test-Path -LiteralPath $output) {
    if (@(Get-ChildItem -LiteralPath $output -Force).Count -gt 0) {
        throw 'Builds\Windows is not empty. Move the previous archive aside before packaging; it will not be overwritten.'
    }
}
$uat = Join-Path $paths.Engine 'Engine\Build\BatchFiles\RunUAT.bat'
& $uat BuildCookRun "-project=$($paths.UProject)" -noP4 -platform=Win64 `
    -clientconfig=Development -build -cook '-map=/Game/Maps/L_Greybox' `
    -stage -pak -package -archive "-archivedirectory=$output" -prereqs -utf8output -unattended
if ($LASTEXITCODE -ne 0) { throw "Packaging failed with code $LASTEXITCODE" }
$executables = @(Get-ChildItem -LiteralPath $output -Filter ThresholdRun.exe -Recurse |
    Where-Object { $_.FullName -match '[\\/]Binaries[\\/]Win64[\\/]' })
if ($executables.Count -ne 1) { throw "Expected one packaged Development game executable under $output" }
Write-Host "Development Win64 archive: $output"
Write-Host "Game binary: $($executables[0].FullName)"

param(
    [string]$EngineRoot,
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)
. "$PSScriptRoot\Windows.Common.ps1"
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw 'An Unreal Win64 game must be built on Windows with UE 5.8 and its C++ toolchain.'
}

# Reuse installed engines; never download or install an engine silently.
if (!$EngineRoot) {
    $candidates = @()
    if ($env:UE_ROOT) { $candidates += $env:UE_ROOT }
    $engineKey = 'HKLM:\SOFTWARE\EpicGames\Unreal Engine\5.8'
    if (Test-Path -LiteralPath $engineKey) {
        $candidates += (Get-ItemProperty -LiteralPath $engineKey -Name InstalledDirectory).InstalledDirectory
    }
    $candidates += Join-Path $env:ProgramFiles 'Epic Games\UE_5.8'
    foreach ($candidate in $candidates) {
        $versionFile = Join-Path $candidate 'Engine\Build\Build.version'
        if (!(Test-Path -LiteralPath $versionFile)) { continue }
        $version = Get-Content -Raw -LiteralPath $versionFile | ConvertFrom-Json
        if ($version.MajorVersion -eq 5 -and $version.MinorVersion -eq 8) {
            $EngineRoot = $candidate
            break
        }
    }
}
if (!$EngineRoot) {
    throw 'UE 5.8 was not found. Install it, or run Build-Playtest.cmd -EngineRoot "D:\Epic Games\UE_5.8".'
}
$paths = Get-ThresholdPaths $EngineRoot $ProjectRoot
$builds = Join-Path $paths.Project 'Builds'
$output = Join-Path $builds 'Windows'
if (Test-Path -LiteralPath $output) {
    # Preserve all previous artifacts rather than deleting or merging them.
    $previous = Join-Path $builds ('Windows-previous-' + [Guid]::NewGuid().ToString('N'))
    Move-Item -LiteralPath $output -Destination $previous
    Write-Host "Previous archive preserved at $previous"
}

Write-Host 'Preparing editor and greybox map...'
& "$PSScriptRoot\Prepare-Windows.ps1" -EngineRoot $paths.Engine -ProjectRoot $paths.Project
Write-Host 'Building the Windows Development game...'
& "$PSScriptRoot\Package-Windows.ps1" -EngineRoot $paths.Engine -ProjectRoot $paths.Project
Write-Host 'Checking the packaged game and save persistence across restarts...'
& "$PSScriptRoot\Run-SmokeTests.ps1" -EngineRoot $paths.Engine -ProjectRoot $paths.Project -Packaged

$launchers = @(Get-ChildItem -LiteralPath $output -Filter ThresholdRun.exe -Recurse |
    Where-Object { $_.FullName.Substring($output.Length) -notmatch '[\\/]Binaries[\\/]' })
if ($launchers.Count -ne 1) { throw "Could not identify the packaged bootstrap executable under $output" }
$playtestZip = Join-Path $builds ('ThresholdRun-Windows-Playtest-' + [Guid]::NewGuid().ToString('N') + '.zip')
# Include cooked content, DLLs, prerequisites and the bootstrap, not just the EXE.
# Use .NET ZIP support instead of Compress-Archive's single-file size limitation.
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($output, $playtestZip)
Write-Host "PASS: Windows playtest packaged and automated checks completed."
Write-Host "Playable launcher: $($launchers[0].FullName)"
Write-Host "Share the complete playtest archive: $playtestZip"
try {
    Start-Process -FilePath explorer.exe -ArgumentList ('/select,"' + $launchers[0].FullName + '"')
} catch {
    Write-Host "Build succeeded. Open the playable launcher shown above manually."
}

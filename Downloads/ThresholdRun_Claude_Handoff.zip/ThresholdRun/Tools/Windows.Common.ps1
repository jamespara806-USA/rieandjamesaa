Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-ThresholdPaths {
    param([string]$EngineRoot, [string]$ProjectRoot)
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
        throw 'These build/run commands require Windows with Unreal Engine 5.8.'
    }
    $engine = (Resolve-Path -LiteralPath $EngineRoot).Path
    $project = (Resolve-Path -LiteralPath $ProjectRoot).Path
    $uproject = Join-Path $project 'ThresholdRun.uproject'
    if (!(Test-Path -LiteralPath $uproject)) { throw "Missing $uproject" }
    $version = Get-Content -Raw -LiteralPath (Join-Path $engine 'Engine\Build\Build.version') | ConvertFrom-Json
    if ($version.MajorVersion -ne 5 -or $version.MinorVersion -ne 8) {
        throw 'This starter targets UE 5.8. Use that engine or explicitly port the project separately.'
    }
    return @{ Engine = $engine; Project = $project; UProject = $uproject }
}

function Invoke-ThresholdProcess {
    param([string]$FilePath, [string[]]$Arguments, [int]$TimeoutSeconds = 180)
    # Windows CRT quoting: preserve spaces, quotes and trailing backslashes.
    $quoted = foreach ($argument in $Arguments) {
        '"' + [regex]::Replace([regex]::Replace($argument, '(\\*)"', '$1$1\"'), '(\\+)$', '$1$1') + '"'
    }
    $process = Start-Process -FilePath $FilePath -ArgumentList ($quoted -join ' ') -PassThru
    if (!$process.WaitForExit($TimeoutSeconds * 1000)) {
        # Stop only this invocation and its children; never stop unrelated editors.
        & taskkill.exe /PID $process.Id /T /F | Out-Null
        throw "Timed out after $TimeoutSeconds seconds: $FilePath"
    }
    $process.Refresh()
    if ($process.ExitCode -ne 0) { throw "Process exited with code $($process.ExitCode): $FilePath" }
}

function Assert-ThresholdReport {
    param([string]$ReportDirectory)
    $index = Join-Path $ReportDirectory 'index.json'
    if (!(Test-Path -LiteralPath $index)) { throw "Missing automation report: $index" }
    $report = Get-Content -Raw -LiteralPath $index | ConvertFrom-Json
    $tests = @($report.tests)
    if ($tests.Count -ne 1 -or $tests[0].fullTestPath -ne 'ThresholdRun.Smoke.GameLoop' `
        -or $tests[0].state -ne 'Success' -or $report.failed -ne 0 `
        -or $report.notRun -ne 0 -or $report.inProcess -ne 0 `
        -or ($report.succeeded + $report.succeededWithWarnings) -ne 1) {
        throw "Smoke test failed, was skipped, or was not discovered: $index"
    }
}

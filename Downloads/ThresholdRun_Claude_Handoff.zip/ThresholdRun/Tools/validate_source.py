"""Static sanity checks. This cannot replace UnrealBuildTool / UHT / Editor Play tests."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'Source' / 'ThresholdRun'
assert json.loads((ROOT / 'ThresholdRun.uproject').read_text())['Modules'][0]['Name'] == 'ThresholdRun'
assert 'EnhancedInput' in (SRC / 'ThresholdRun.Build.cs').read_text()
assert (ROOT / 'Config' / 'DefaultInput.ini').is_file()
files = list(SRC.rglob('*.h')) + list(SRC.rglob('*.cpp'))
assert len(files) >= 25
for p in files:
    raw = p.read_text()
    if p.suffix == '.h' and p.name != 'ThresholdRun.Build.cs':
        if '.generated.h' in raw:
            assert raw.count('.generated.h') == 1, p
            includes = re.findall(r'^#include\s+"([^"]+)"', raw, re.M)
            assert includes[-1].endswith('.generated.h'), p
    # Only simple delimiter counts; comments/strings can create false positives.
    for a,b in [('(',')'),('{','}'),('[',']')]:
        assert raw.count(a) == raw.count(b), (p,a,raw.count(a),raw.count(b))
    for inc in re.findall(r'^#include\s+"([^"]+)"', raw, re.M):
        if inc.startswith(('Player/','UI/','Interaction/','Survival/','Puzzles/','Progression/','World/')):
            assert (SRC/inc).exists(), (p,inc)
needed = [
 'Player/GreyPlayer.cpp','Survival/SurvivalVitals.cpp','Puzzles/GreyGate.cpp',
 'Puzzles/PressurePlate.cpp','Puzzles/LogicRelay.cpp',
 'World/GreyWorldBuilder.cpp','Progression/GreyGameInstance.cpp'
]
for n in needed: assert (SRC/n).is_file()
builder=(SRC/'World/GreyWorldBuilder.cpp').read_text()
for token in ['Gate1->Configure(First','Gate2->Configure(Relay','Relay->Configure(Inputs,true)',
              'EPickupKind::Shortcut','EPickupKind::Blueprint','EPickupKind::Warmth',
              'FRandomStream','MakeOptionalBranch','APointLight']:
    assert token in builder, token
player=(SRC/'Player/GreyPlayer.cpp').read_text()
for token in ['EKeys::W','EKeys::E','EKeys::MouseX','LineTraceSingleByChannel',
              'Execute_CanInteract','Execute_Interact']:
    assert token in player, token
print(f'OK: {len(files)} C++ source files; valid .uproject; local includes, headers, FSM wiring, save and input structural checks.')
print('NOTE: UE5 compiler/UHT and runtime collision/input tests NOT executed.')

#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "SurvivalVitals.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FVitalsDeath);
UCLASS(ClassGroup=(Survival), meta=(BlueprintSpawnableComponent))
class THRESHOLDRUN_API USurvivalVitals : public UActorComponent
{
    GENERATED_BODY()
public:
    USurvivalVitals();
    virtual void TickComponent(float Delta, ELevelTick TickType, FActorComponentTickFunction* Tick) override;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Vitals") float MaxValue = 100.f;
    UPROPERTY(BlueprintReadOnly, Category="Vitals") float Energy = 100.f;
    UPROPERTY(BlueprintReadOnly, Category="Vitals") float Oxygen = 100.f;
    UPROPERTY(BlueprintReadOnly, Category="Vitals") float Warmth = 100.f;
    UPROPERTY(EditAnywhere, Category="Vitals") float BaseEnergyDrainPerSecond = 0.35f;
    UPROPERTY(EditAnywhere, Category="Vitals") float SprintEnergyDrainPerSecond = 4.0f;
    UPROPERTY(EditAnywhere, Category="Vitals") float EnergyRecoveryPerSecond = 1.75f;
    UPROPERTY(BlueprintAssignable) FVitalsDeath OnDied;
    UFUNCTION(BlueprintCallable) bool SpendEnergy(float Amount);
    UFUNCTION(BlueprintCallable) void Restore(float EnergyDelta, float OxygenDelta, float WarmthDelta);
    UFUNCTION(BlueprintCallable) void AddExposure(float OxygenDrainPerSecond, float WarmthDrainPerSecond);
    UFUNCTION(BlueprintCallable) void RemoveExposure(float OxygenDrainPerSecond, float WarmthDrainPerSecond);
    UFUNCTION(BlueprintPure) bool CanSprint() const { return Energy > 5.f && !bDead; }
    UFUNCTION(BlueprintCallable) void SetSprinting(bool bValue) { bSprinting = bValue; }
    UFUNCTION(BlueprintPure) bool IsDead() const { return bDead; }
private:
    bool bSprinting = false;
    bool bDead = false;
    float OxygenExposure = 0.f;
    float WarmthExposure = 0.f;
    void CheckDeath();
};

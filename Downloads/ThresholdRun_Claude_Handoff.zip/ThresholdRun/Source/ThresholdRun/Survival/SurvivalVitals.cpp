#include "Survival/SurvivalVitals.h"
USurvivalVitals::USurvivalVitals() { PrimaryComponentTick.bCanEverTick = true; }
void USurvivalVitals::TickComponent(float Delta, ELevelTick TickType, FActorComponentTickFunction* Tick)
{
    Super::TickComponent(Delta, TickType, Tick);
    if (bDead) return;
    const bool bActuallySprint = bSprinting && Energy > 0.f;
    const float EnergyDelta = bActuallySprint ? -(BaseEnergyDrainPerSecond + SprintEnergyDrainPerSecond) * Delta
                                             : (EnergyRecoveryPerSecond - BaseEnergyDrainPerSecond) * Delta;
    Energy = FMath::Clamp(Energy + EnergyDelta, 0.f, MaxValue);
    Oxygen = FMath::Clamp(Oxygen - OxygenExposure * Delta, 0.f, MaxValue);
    Warmth = FMath::Clamp(Warmth - WarmthExposure * Delta, 0.f, MaxValue);
    CheckDeath();
}
bool USurvivalVitals::SpendEnergy(float Amount)
{
    if (Amount < 0.f || bDead || Energy < Amount) return false;
    Energy -= Amount; CheckDeath(); return true;
}
void USurvivalVitals::Restore(float E, float O, float W)
{
    if (bDead) return;
    Energy = FMath::Clamp(Energy + E, 0.f, MaxValue);
    Oxygen = FMath::Clamp(Oxygen + O, 0.f, MaxValue);
    Warmth = FMath::Clamp(Warmth + W, 0.f, MaxValue);
}
void USurvivalVitals::AddExposure(float O, float W)
{
    OxygenExposure += FMath::Max(O, 0.f);
    WarmthExposure += FMath::Max(W, 0.f);
}
void USurvivalVitals::RemoveExposure(float O, float W)
{
    OxygenExposure = FMath::Max(0.f, OxygenExposure - FMath::Max(O, 0.f));
    WarmthExposure = FMath::Max(0.f, WarmthExposure - FMath::Max(W, 0.f));
}
void USurvivalVitals::CheckDeath()
{
    if (!bDead && (Energy <= 0.f || Oxygen <= 0.f || Warmth <= 0.f))
    { bDead = true; OnDied.Broadcast(); }
}

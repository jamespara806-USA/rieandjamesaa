#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ExposureZone.generated.h"
class UBoxComponent;
class USurvivalVitals;
UCLASS(Blueprintable)
class THRESHOLDRUN_API AExposureZone : public AActor
{
    GENERATED_BODY()
public:
    AExposureZone();
    UPROPERTY(VisibleAnywhere) TObjectPtr<UBoxComponent> Trigger;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float OxygenDrainPerSecond = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float WarmthDrainPerSecond = 11.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FVector BoxExtent = FVector(420.f, 450.f, 150.f);
    virtual void BeginPlay() override;
private:
    UFUNCTION() void Enter(UPrimitiveComponent*, AActor*, UPrimitiveComponent*, int32, bool, const FHitResult&);
    UFUNCTION() void Exit(UPrimitiveComponent*, AActor*, UPrimitiveComponent*, int32);
    UPROPERTY() TArray<TObjectPtr<USurvivalVitals>> Occupants;
    virtual void EndPlay(const EEndPlayReason::Type Reason) override;
};

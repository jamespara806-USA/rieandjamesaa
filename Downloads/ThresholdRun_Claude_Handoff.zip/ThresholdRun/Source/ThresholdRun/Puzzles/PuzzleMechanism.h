#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PuzzleMechanism.generated.h"
class UStaticMeshComponent;
class UTextRenderComponent;
class APuzzleMechanism;
UENUM(BlueprintType)
enum class EPuzzleState : uint8 { Locked, Unpowered, Ready, Activated, Triggered };
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FPuzzleStateChanged, APuzzleMechanism*, Mechanism, EPuzzleState, Before, EPuzzleState, After);
UCLASS(Blueprintable)
class THRESHOLDRUN_API APuzzleMechanism : public AActor
{
    GENERATED_BODY()
public:
    APuzzleMechanism();
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UStaticMeshComponent> Visual;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UTextRenderComponent> Caption;
    UPROPERTY(BlueprintReadOnly, Category="Puzzle") EPuzzleState State = EPuzzleState::Ready;
    UPROPERTY(BlueprintAssignable, Category="Puzzle") FPuzzleStateChanged OnStateChanged;
    UFUNCTION(BlueprintCallable, Category="Puzzle") bool TryActivate();
    UFUNCTION(BlueprintCallable, Category="Puzzle") bool TryTrigger();
    UFUNCTION(BlueprintCallable, Category="Puzzle") void ResetMechanism();
    UFUNCTION(BlueprintCallable, Category="Puzzle") void SetPowered(bool bValue);
    UFUNCTION(BlueprintCallable, Category="Puzzle") void SetLocked(bool bValue);
    UFUNCTION(BlueprintCallable) void SetCaptionText(const FString& Text);
    UFUNCTION(BlueprintPure) bool IsTriggered() const { return State == EPuzzleState::Triggered; }
protected:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Puzzle") bool bLocked = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Puzzle") bool bPowered = true;
    bool bActivated = false;
    bool bTriggered = false;
    void RefreshState();
};

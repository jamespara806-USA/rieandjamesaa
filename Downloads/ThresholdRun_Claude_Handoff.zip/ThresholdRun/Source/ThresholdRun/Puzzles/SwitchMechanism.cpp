#include "Puzzles/SwitchMechanism.h"
#include "Survival/SurvivalVitals.h"
ASwitchMechanism::ASwitchMechanism() { SetCaptionText(TEXT("SWITCH [E]")); }
bool ASwitchMechanism::CanInteract_Implementation(APawn* Pawn) const
{
    const USurvivalVitals* V = Pawn ? Pawn->FindComponentByClass<USurvivalVitals>() : nullptr;
    return State == EPuzzleState::Ready && V && !V->IsDead() && V->Energy >= EnergyCost;
}
FText ASwitchMechanism::InteractionLabel_Implementation(APawn*) const
{
    if (IsTriggered()) return FText::FromString(TEXT("Switch activated"));
    return FText::FromString(FString::Printf(TEXT("Press E: activate switch (%.0f energy)"), EnergyCost));
}
void ASwitchMechanism::Interact_Implementation(APawn* Pawn)
{
    if (!CanInteract_Implementation(Pawn)) return;
    USurvivalVitals* V = Pawn->FindComponentByClass<USurvivalVitals>();
    if (V && V->SpendEnergy(EnergyCost) && TryActivate() && TryTrigger()) OnSwitchUsed();
}

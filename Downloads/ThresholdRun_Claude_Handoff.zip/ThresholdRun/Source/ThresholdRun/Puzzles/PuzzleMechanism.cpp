#include "Puzzles/PuzzleMechanism.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "UObject/ConstructorHelpers.h"
APuzzleMechanism::APuzzleMechanism()
{
    PrimaryActorTick.bCanEverTick = false;
    Visual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Visual"));
    SetRootComponent(Visual);
    static ConstructorHelpers::FObjectFinder<UStaticMesh> Cube(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (Cube.Succeeded()) Visual->SetStaticMesh(Cube.Object);
    Visual->SetCollisionProfileName(TEXT("BlockAll"));
    Visual->SetRelativeScale3D(FVector(0.8f,0.8f,1.2f));
    Caption = CreateDefaultSubobject<UTextRenderComponent>(TEXT("Caption"));
    Caption->SetupAttachment(Visual);
    Caption->SetRelativeLocation(FVector(0.f,0.f,105.f));
    Caption->SetRelativeScale3D(FVector(1.25f));
    Caption->SetHorizontalAlignment(EHTA_Center);
    Caption->SetTextRenderColor(FColor::Cyan);
    Caption->SetWorldSize(22.f);
    Caption->SetText(FText::FromString(TEXT("Puzzle")));
}
void APuzzleMechanism::SetCaptionText(const FString& Text)
{ Caption->SetText(FText::FromString(Text)); }
void APuzzleMechanism::RefreshState()
{
    const EPuzzleState NewState = bTriggered ? EPuzzleState::Triggered : bLocked ? EPuzzleState::Locked
        : !bPowered ? EPuzzleState::Unpowered : bActivated ? EPuzzleState::Activated : EPuzzleState::Ready;
    if (NewState != State)
    {
        const EPuzzleState OldState = State;
        State = NewState;
        Caption->SetTextRenderColor(State == EPuzzleState::Triggered ? FColor::Green : FColor::Cyan);
        OnStateChanged.Broadcast(this, OldState, State);
    }
}
bool APuzzleMechanism::TryActivate()
{
    if (State != EPuzzleState::Ready) return false;
    bActivated = true; RefreshState(); return true;
}
bool APuzzleMechanism::TryTrigger()
{
    if (State != EPuzzleState::Activated) return false;
    bTriggered = true; RefreshState(); return true;
}
void APuzzleMechanism::ResetMechanism()
{ bTriggered = false; bActivated = false; RefreshState(); }
void APuzzleMechanism::SetPowered(bool Value)
{ bPowered = Value; if (!bPowered && !bTriggered) bActivated = false; RefreshState(); }
void APuzzleMechanism::SetLocked(bool Value)
{ bLocked = Value; if (bLocked && !bTriggered) bActivated = false; RefreshState(); }

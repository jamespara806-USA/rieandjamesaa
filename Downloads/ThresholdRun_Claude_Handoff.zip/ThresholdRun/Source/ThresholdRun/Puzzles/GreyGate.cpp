#include "Puzzles/GreyGate.h"
#include "Puzzles/PuzzleMechanism.h"
#include "Progression/GreyGameInstance.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "UObject/ConstructorHelpers.h"
AGreyGate::AGreyGate()
{
    Barrier = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("GateBarrier"));
    SetRootComponent(Barrier);
    static ConstructorHelpers::FObjectFinder<UStaticMesh> Cube(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (Cube.Succeeded()) Barrier->SetStaticMesh(Cube.Object);
    Barrier->SetRelativeScale3D(FVector(0.75f,5.0f,3.1f));
    Barrier->SetCollisionProfileName(TEXT("BlockAll"));
    Caption = CreateDefaultSubobject<UTextRenderComponent>(TEXT("GateCaption"));
    Caption->SetupAttachment(Barrier);
    Caption->SetRelativeLocation(FVector(0,0,70));
    Caption->SetAbsolute(false,false,true);
    Caption->SetWorldSize(30.f);
    Caption->SetHorizontalAlignment(EHTA_Center);
    Caption->SetText(FText::FromString(TEXT("LOCKED")));
}
void AGreyGate::Configure(APuzzleMechanism* InSource, FName InShortcut)
{
    if (Source) Source->OnStateChanged.RemoveDynamic(this, &AGreyGate::SourceChanged);
    Source = InSource; ShortcutID = InShortcut;
    if (Source) Source->OnStateChanged.AddDynamic(this, &AGreyGate::SourceChanged);
    RefreshGate();
}
void AGreyGate::SourceChanged(APuzzleMechanism*, EPuzzleState, EPuzzleState) { RefreshGate(); }
void AGreyGate::RefreshGate()
{
    const UGreyGameInstance* GI = Cast<UGreyGameInstance>(GetGameInstance());
    const bool bShouldOpen = (Source && Source->IsTriggered()) || (GI && GI->HasShortcut(ShortcutID));
    if (bOpen || !bShouldOpen) return;
    bOpen = true;
    Barrier->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    Barrier->SetVisibility(false, true);
    Caption->SetVisibility(false);
    OnGateOpened();
}
void AGreyGate::EndPlay(const EEndPlayReason::Type Reason)
{
    if (Source) Source->OnStateChanged.RemoveDynamic(this, &AGreyGate::SourceChanged);
    Super::EndPlay(Reason);
}

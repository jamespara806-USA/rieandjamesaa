#include "Player/GreyPlayer.h"
#include "Survival/SurvivalVitals.h"
#include "Progression/GreyGameMode.h"
#include "Interaction/PrototypeInteractable.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputAction.h"
#include "InputMappingContext.h"
#include "InputModifiers.h"
#include "InputCoreTypes.h"
#include "Engine/LocalPlayer.h"

AGreyPlayer::AGreyPlayer()
{
    PrimaryActorTick.bCanEverTick=true;
    GetCapsuleComponent()->InitCapsuleSize(42.f,88.f);
    GetMesh()->SetHiddenInGame(true);
    Camera=CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
    Camera->SetupAttachment(GetCapsuleComponent());
    Camera->SetRelativeLocation(FVector(0,0,65.f));
    Camera->bUsePawnControlRotation=true;
    Vitals=CreateDefaultSubobject<USurvivalVitals>(TEXT("SurvivalVitals"));
    bUseControllerRotationYaw=true;
    GetCharacterMovement()->bOrientRotationToMovement=false;
    GetCharacterMovement()->NavAgentProps.bCanCrouch=true;
    GetCharacterMovement()->MaxWalkSpeed=WalkSpeed;
    GetCharacterMovement()->MaxWalkSpeedCrouched=220.f;
    GetCharacterMovement()->JumpZVelocity=430.f;
    GetCharacterMovement()->AirControl=0.32f;
}
void AGreyPlayer::BeginPlay()
{
    Super::BeginPlay(); Vitals->OnDied.AddDynamic(this, &AGreyPlayer::OnVitalsDeath);
    if (APlayerController* PC=Cast<APlayerController>(GetController()))
    { PC->bShowMouseCursor=false; PC->SetInputMode(FInputModeGameOnly()); }
}
void AGreyPlayer::OnVitalsDeath()
{
    DisableInput(Cast<APlayerController>(GetController()));
    if (AGreyGameMode* GM=Cast<AGreyGameMode>(GetWorld()->GetAuthGameMode())) GM->EndRun(false);
}
void AGreyPlayer::Tick(float Delta)
{
    Super::Tick(Delta);
    const bool bSprint = bWantsSprint && !bIsCrouched && Vitals->CanSprint() && GetVelocity().SizeSquared2D() > 50.f;
    GetCharacterMovement()->MaxWalkSpeed=bSprint ? SprintSpeed : WalkSpeed;
    Vitals->SetSprinting(bSprint);
}
void AGreyPlayer::SetupPlayerInputComponent(UInputComponent* Input)
{
    Super::SetupPlayerInputComponent(Input);
    UEnhancedInputComponent* Enhanced=Cast<UEnhancedInputComponent>(Input);
    if (!Enhanced) { UE_LOG(LogTemp,Error,TEXT("ThresholdRun requires EnhancedInputComponent. Check Config/DefaultInput.ini")); return; }
    RuntimeMappings=NewObject<UInputMappingContext>(this);
    auto Action = [this](EInputActionValueType Type) -> UInputAction*
    {
        UInputAction* A=NewObject<UInputAction>(this); A->ValueType=Type; return A;
    };
    ForwardAction=Action(EInputActionValueType::Axis1D);
    RightAction=Action(EInputActionValueType::Axis1D);
    YawAction=Action(EInputActionValueType::Axis1D);
    PitchAction=Action(EInputActionValueType::Axis1D);
    JumpAction=Action(EInputActionValueType::Boolean);
    SprintAction=Action(EInputActionValueType::Boolean);
    CrouchAction=Action(EInputActionValueType::Boolean);
    InteractAction=Action(EInputActionValueType::Boolean);
    RuntimeMappings->MapKey(ForwardAction, EKeys::W);
    RuntimeMappings->MapKey(ForwardAction, EKeys::S).Modifiers.Add(NewObject<UInputModifierNegate>(RuntimeMappings));
    RuntimeMappings->MapKey(RightAction, EKeys::D);
    RuntimeMappings->MapKey(RightAction, EKeys::A).Modifiers.Add(NewObject<UInputModifierNegate>(RuntimeMappings));
    RuntimeMappings->MapKey(YawAction, EKeys::MouseX);
    RuntimeMappings->MapKey(PitchAction, EKeys::MouseY).Modifiers.Add(NewObject<UInputModifierNegate>(RuntimeMappings));
    RuntimeMappings->MapKey(JumpAction, EKeys::SpaceBar);
    RuntimeMappings->MapKey(SprintAction, EKeys::LeftShift);
    RuntimeMappings->MapKey(CrouchAction, EKeys::LeftControl);
    RuntimeMappings->MapKey(InteractAction, EKeys::E);
    Enhanced->BindAction(ForwardAction, ETriggerEvent::Triggered,this,&AGreyPlayer::Forward);
    Enhanced->BindAction(RightAction,ETriggerEvent::Triggered,this,&AGreyPlayer::Right);
    Enhanced->BindAction(YawAction,ETriggerEvent::Triggered,this,&AGreyPlayer::Yaw);
    Enhanced->BindAction(PitchAction,ETriggerEvent::Triggered,this,&AGreyPlayer::Pitch);
    Enhanced->BindAction(JumpAction,ETriggerEvent::Started,this,&AGreyPlayer::StartJump);
    Enhanced->BindAction(JumpAction,ETriggerEvent::Completed,this,&AGreyPlayer::StopJumpAction);
    Enhanced->BindAction(SprintAction,ETriggerEvent::Started,this,&AGreyPlayer::StartSprint);
    Enhanced->BindAction(SprintAction,ETriggerEvent::Completed,this,&AGreyPlayer::EndSprint);
    Enhanced->BindAction(CrouchAction,ETriggerEvent::Started,this,&AGreyPlayer::ToggleCrouch);
    Enhanced->BindAction(InteractAction,ETriggerEvent::Started,this,&AGreyPlayer::InteractPressed);
    if (APlayerController* PC=Cast<APlayerController>(GetController()))
    {
        if (ULocalPlayer* LP=PC->GetLocalPlayer())
            if (UEnhancedInputLocalPlayerSubsystem* Sys=LP->GetSubsystem<UEnhancedInputLocalPlayerSubsystem>())
                Sys->AddMappingContext(RuntimeMappings, 0);
    }
}
void AGreyPlayer::Forward(const FInputActionValue& V) { AddMovementInput(GetActorForwardVector(),V.Get<float>()); }
void AGreyPlayer::Right(const FInputActionValue& V) { AddMovementInput(GetActorRightVector(),V.Get<float>()); }
void AGreyPlayer::Yaw(const FInputActionValue& V) { AddControllerYawInput(V.Get<float>()); }
void AGreyPlayer::Pitch(const FInputActionValue& V) { AddControllerPitchInput(V.Get<float>()); }
void AGreyPlayer::StartSprint(const FInputActionValue&) { bWantsSprint=true; }
void AGreyPlayer::EndSprint(const FInputActionValue&) { bWantsSprint=false; }
void AGreyPlayer::StartJump(const FInputActionValue&) { Jump(); }
void AGreyPlayer::StopJumpAction(const FInputActionValue&) { StopJumping(); }
void AGreyPlayer::ToggleCrouch(const FInputActionValue&) { if (bIsCrouched) UnCrouch(); else Crouch(); }
void AGreyPlayer::InteractPressed(const FInputActionValue&) { TryInteract(); }
AActor* AGreyPlayer::FindInteractable() const
{
    if (!GetWorld() || !Camera) return nullptr;
    const FVector Start=Camera->GetComponentLocation();
    const FVector End=Start+Camera->GetForwardVector()*InteractDistance;
    FHitResult Hit;
    FCollisionQueryParams Params(SCENE_QUERY_STAT(GreyInteract), false, this);
    // First blocking hit wins: never raycast through a wall to a puzzle object.
    if (!GetWorld()->LineTraceSingleByChannel(Hit,Start,End,ECC_Visibility,Params)) return nullptr;
    AActor* Candidate=Hit.GetActor();
    return Candidate && Candidate->GetClass()->ImplementsInterface(UPrototypeInteractable::StaticClass()) ? Candidate : nullptr;
}
FText AGreyPlayer::GetInteractionPrompt() const
{
    AActor* Target=FindInteractable();
    if (!Target) return FText::GetEmpty();
    if (!IPrototypeInteractable::Execute_CanInteract(Target,const_cast<AGreyPlayer*>(this)))
        return FText::FromString(TEXT("Cannot interact (already used or insufficient energy)"));
    return IPrototypeInteractable::Execute_InteractionLabel(Target,const_cast<AGreyPlayer*>(this));
}
void AGreyPlayer::TryInteract()
{
    if (Vitals->IsDead()) return;
    if (AActor* Target=FindInteractable())
        if (IPrototypeInteractable::Execute_CanInteract(Target,this))
            IPrototypeInteractable::Execute_Interact(Target,this);
}

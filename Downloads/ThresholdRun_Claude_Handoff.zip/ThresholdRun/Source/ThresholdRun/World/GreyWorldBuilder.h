#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/World.h"
#include "GreyWorldBuilder.generated.h"
class ASwitchMechanism;
class APressurePlate;
class ALogicRelay;
class AGreyGate;
class AGreyPickup;
class AGreyExit;
UCLASS(Blueprintable)
class THRESHOLDRUN_API AGreyWorldBuilder : public AActor
{
    GENERATED_BODY()
public:
    AGreyWorldBuilder();
    UPROPERTY(EditDefaultsOnly,BlueprintReadOnly,Category="Blueprint Extensions") TSubclassOf<ASwitchMechanism> SwitchClass;
    UPROPERTY(EditDefaultsOnly,BlueprintReadOnly,Category="Blueprint Extensions") TSubclassOf<APressurePlate> PlateClass;
    UPROPERTY(EditDefaultsOnly,BlueprintReadOnly,Category="Blueprint Extensions") TSubclassOf<AGreyGate> GateClass;
    UPROPERTY(EditDefaultsOnly,BlueprintReadOnly,Category="Blueprint Extensions") TSubclassOf<AGreyPickup> PickupClass;
    UPROPERTY(EditDefaultsOnly,BlueprintReadOnly,Category="Blueprint Extensions") TSubclassOf<AGreyExit> ExitClass;
    UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Generation") bool bAllowOptionalBranch = true;
    virtual void BeginPlay() override;
private:
    AActor* Block(const FVector& Center,const FVector& Dimensions);
    void Sign(const FString& Text,const FVector& Location,const FColor& Color = FColor::Cyan);
    void MakeRoom(int32 Slot,bool bBranch);
    void MakeOptionalBranch();
    template<typename T> T* SpawnPiece(TSubclassOf<T> Class,const FVector& Location)
    {
        FActorSpawnParameters P;
        P.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
        return GetWorld()->SpawnActor<T>(Class ? Class.Get() : T::StaticClass(),Location,FRotator::ZeroRotator,P);
    }
};

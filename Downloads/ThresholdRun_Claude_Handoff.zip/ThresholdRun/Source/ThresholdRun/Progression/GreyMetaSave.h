#pragma once
#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "GreyMetaSave.generated.h"

UCLASS(BlueprintType)
class THRESHOLDRUN_API UGreyMetaSave : public USaveGame
{
    GENERATED_BODY()
public:
    UPROPERTY(BlueprintReadOnly, SaveGame) int32 RunsCompleted = 0;
    UPROPERTY(BlueprintReadOnly, SaveGame) int32 Victories = 0;
    UPROPERTY(BlueprintReadOnly, SaveGame) int32 NextSeed = 12345;
    UPROPERTY(BlueprintReadOnly, SaveGame) TArray<FName> Shortcuts;
    UPROPERTY(BlueprintReadOnly, SaveGame) TArray<FName> Blueprints;
    UPROPERTY(BlueprintReadOnly, SaveGame) TArray<FName> Knowledge;
};

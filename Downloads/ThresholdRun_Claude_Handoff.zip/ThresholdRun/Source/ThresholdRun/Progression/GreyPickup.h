#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interaction/PrototypeInteractable.h"
#include "GreyPickup.generated.h"
class UStaticMeshComponent;
class UTextRenderComponent;
UENUM(BlueprintType)
enum class EPickupKind : uint8 { Energy, Oxygen, Warmth, Shortcut, Blueprint, Knowledge };
UCLASS(Blueprintable)
class THRESHOLDRUN_API AGreyPickup : public AActor, public IPrototypeInteractable
{
    GENERATED_BODY()
public:
    AGreyPickup();
    UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> Visual;
    UPROPERTY(VisibleAnywhere) TObjectPtr<UTextRenderComponent> Caption;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) EPickupKind Kind = EPickupKind::Energy;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float RestoreAmount = 45.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FName PersistentID;
    UFUNCTION(BlueprintCallable) void Configure(EPickupKind NewKind, FName NewID, float NewAmount = 45.f);
    virtual bool CanInteract_Implementation(APawn* Pawn) const override;
    virtual FText InteractionLabel_Implementation(APawn* Pawn) const override;
    virtual void Interact_Implementation(APawn* Pawn) override;
    UFUNCTION(BlueprintImplementableEvent) void OnCollected();
};

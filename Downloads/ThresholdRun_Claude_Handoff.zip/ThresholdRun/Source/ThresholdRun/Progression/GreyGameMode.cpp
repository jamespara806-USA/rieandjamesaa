#include "Progression/GreyGameMode.h"
#include "Progression/GreyGameInstance.h"
#include "Player/GreyPlayer.h"
#include "UI/GreyHUD.h"
#include "World/GreyWorldBuilder.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "TimerManager.h"
AGreyGameMode::AGreyGameMode()
{
    DefaultPawnClass=AGreyPlayer::StaticClass();
    HUDClass=AGreyHUD::StaticClass();
}
void AGreyGameMode::BeginPlay()
{
    Super::BeginPlay();
    // A placed BP subclass is supported. Otherwise make the complete demo world natively.
    bool bBuilderExists = false;
    for (TActorIterator<AGreyWorldBuilder> It(GetWorld()); It; ++It)
    { bBuilderExists=true; break; }
    if (!bBuilderExists) GetWorld()->SpawnActor<AGreyWorldBuilder>();
}
void AGreyGameMode::EndRun(bool bVictory)
{
    if (bEnding) return;
    bEnding = true;
    if (UGreyGameInstance* GI=Cast<UGreyGameInstance>(GetGameInstance())) GI->CompleteRun(bVictory);
    GetWorldTimerManager().SetTimer(ReloadTimer, this, &AGreyGameMode::ReloadLevel, 1.5f, false);
}
void AGreyGameMode::ReloadLevel()
{
    const FString CurrentMap=UGameplayStatics::GetCurrentLevelName(this, true);
    UGameplayStatics::OpenLevel(this, FName(*CurrentMap));
}

#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interaction/PrototypeInteractable.h"
#include "GreyExit.generated.h"
class UStaticMeshComponent;
class UTextRenderComponent;
UCLASS(Blueprintable)
class THRESHOLDRUN_API AGreyExit : public AActor, public IPrototypeInteractable
{
    GENERATED_BODY()
public:
    AGreyExit();
    UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> Visual;
    UPROPERTY(VisibleAnywhere) TObjectPtr<UTextRenderComponent> Caption;
    virtual bool CanInteract_Implementation(APawn* Pawn) const override;
    virtual FText InteractionLabel_Implementation(APawn* Pawn) const override;
    virtual void Interact_Implementation(APawn* Pawn) override;
};

#pragma once
#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "GreyGameInstance.generated.h"
class UGreyMetaSave;

UCLASS()
class THRESHOLDRUN_API UGreyGameInstance : public UGameInstance
{
    GENERATED_BODY()
public:
    virtual void Init() override;
    UFUNCTION(BlueprintPure) bool HasShortcut(FName ID) const;
    UFUNCTION(BlueprintPure) int32 GetRunSeed() const;
    UFUNCTION(BlueprintPure) int32 GetRunNumber() const;
    UFUNCTION(BlueprintCallable) bool UnlockShortcut(FName ID);
    UFUNCTION(BlueprintCallable) bool UnlockBlueprint(FName ID);
    UFUNCTION(BlueprintCallable) bool UnlockKnowledge(FName ID);
    UFUNCTION(BlueprintCallable) void CompleteRun(bool bVictory);
    UFUNCTION(BlueprintPure) FString GetRunMessage() const { return RunMessage; }
    UPROPERTY(BlueprintReadOnly) TObjectPtr<UGreyMetaSave> Meta;
private:
    bool SaveMeta();
    UPROPERTY() int32 CurrentSeed = 12345;
    FString RunMessage = TEXT("Solve the doors; knowledge survives death.");
    static constexpr int32 SaveUser = 0;
};

// Runtime module: available to Development games, including packaged Win64.
// No test actor is placed in the map; this latent command survives OpenLevel.
#include "CoreMinimal.h"

#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformTime.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/PlayerController.h"
#include "Player/GreyPlayer.h"
#include "Survival/SurvivalVitals.h"
#include "Puzzles/SwitchMechanism.h"
#include "Puzzles/GreyGate.h"
#include "Progression/GreyGameMode.h"
#include "Progression/GreyGameInstance.h"
#include "Progression/GreyMetaSave.h"

namespace ThresholdSmoke
{
const FString Slot = TEXT("ThresholdRunMeta_v1");
const FName Shortcut(TEXT("shortcut_gate_1"));
const FName Blueprint(TEXT("blueprint_thermal_lens"));

UWorld* FindWorld()
{
    if (GEngine)
        for (const FWorldContext& Context : GEngine->GetWorldContexts())
            if (Context.WorldType == EWorldType::Game && Context.World()) return Context.World();
    return nullptr;
}

template<class T> T* FindAtX(UWorld* World, float X)
{
    for (TActorIterator<T> It(World); It; ++It)
        if (FMath::Abs(It->GetActorLocation().X - X) < 1.f) return *It;
    return nullptr;
}

bool IsOpen(const AGreyGate* Gate)
{
    return Gate && Gate->bOpen && Gate->Barrier
        && Gate->Barrier->GetCollisionEnabled() == ECollisionEnabled::NoCollision
        && !Gate->Barrier->IsVisible();
}

class FGameLoop final : public IAutomationLatentCommand
{
    enum class EStep { Startup, Gate, Death, Reload };
    FAutomationTestBase* Test;
    EStep Step = EStep::Startup;
    double Deadline = FPlatformTime::Seconds() + 30.0;
    double SwitchStarted = 0;
    bool bRestart = false;
    FString Root;
    TWeakObjectPtr<UWorld> OriginalWorld;
    TWeakObjectPtr<AGreyPlayer> OriginalPlayer;
    TWeakObjectPtr<AGreyGate> Gate;

    bool Fail(const FString& Why) { Test->AddError(Why); return true; }
    bool Check(bool Value, const TCHAR* Why)
    {
        if (!Value) Test->AddError(Why);
        return Value;
    }
    bool VitalsOK(AGreyPlayer* Player)
    {
        const USurvivalVitals* V = Player ? Player->Vitals.Get() : nullptr;
        return V && V->IsRegistered() && !V->IsDead()
            && FMath::IsNearlyEqual(V->MaxValue, 100.f)
            && FMath::IsNearlyEqual(V->Energy, 100.f, 0.01f)
            && FMath::IsNearlyEqual(V->Oxygen, 100.f, 0.01f)
            && FMath::IsNearlyEqual(V->Warmth, 100.f, 0.01f);
    }
    bool VerifyMeta(const UGreyMetaSave* Meta, int32 Runs, int32 Seed)
    {
        return Check(Meta && Meta->RunsCompleted == Runs && Meta->Victories == 0
            && Meta->NextSeed == Seed && Meta->Shortcuts.Num() == 1
            && Meta->Shortcuts.Contains(Shortcut) && Meta->Blueprints.Num() == 1
            && Meta->Blueprints.Contains(Blueprint) && Meta->Knowledge.IsEmpty(),
            TEXT("SaveGame shortcut/blueprint, run count, victory count or seed mismatch"));
    }
    bool VerifyDisk(int32 Runs, int32 Seed)
    {
        // Load a new object from disk, independent of the GameInstance cache.
        return VerifyMeta(Cast<UGreyMetaSave>(
            UGameplayStatics::LoadGameFromSlot(Slot, 0)), Runs, Seed);
    }
    bool VerifyTransientReset(UWorld* World)
    {
        const ASwitchMechanism* Second = FindAtX<ASwitchMechanism>(World, 2520.f);
        const AGreyGate* SecondGate = FindAtX<AGreyGate>(World, 3300.f);
        return Check(Second && Second->State == EPuzzleState::Ready
            && SecondGate && !SecondGate->bOpen,
            TEXT("Second puzzle must start ready with gate 2 closed"));
    }
    bool Receipt(const TCHAR* Name)
    {
        return Check(FFileHelper::SaveStringToFile(TEXT("PASS\n"),
            *FPaths::Combine(Root, Name)), TEXT("Could not write smoke receipt"));
    }
public:
    explicit FGameLoop(FAutomationTestBase* InTest) : Test(InTest) {}
    bool Update() override
    {
        UWorld* W = FindWorld();
        const double Now = FPlatformTime::Seconds();
        if (Now > Deadline) return Fail(FString::Printf(TEXT("Smoke timeout in phase %d"), int32(Step)));
        if (!W || !W->HasBegunPlay()) return false;
        AGreyPlayer* Player = Cast<AGreyPlayer>(UGameplayStatics::GetPlayerPawn(W, 0));
        UGreyGameInstance* GI = Cast<UGreyGameInstance>(W->GetGameInstance());

        if (Step == EStep::Startup)
        {
            // Refuse writes unless the runner has routed the actual Saved directory
            // into a dedicated sandbox. Production slot names remain unchanged.
            FString UserDir;
            if (!FParse::Value(FCommandLine::Get(), TEXT("ThresholdSmokeRoot="), Root)
                || !FParse::Value(FCommandLine::Get(), TEXT("UserDir="), UserDir)
                || !FParse::Param(FCommandLine::Get(), TEXT("SaveToUserDir")))
                return Fail(TEXT("Use Tools/Run-SmokeTests.ps1: isolated UserDir is required"));
            Root = FPaths::ConvertRelativePathToFull(Root);
            UserDir = FPaths::ConvertRelativePathToFull(UserDir);
            FPaths::NormalizeDirectoryName(Root);
            FPaths::NormalizeDirectoryName(UserDir);
            if (!FPaths::IsSamePath(Root, UserDir)
                || !FPaths::IsUnderDirectory(FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir()), Root))
                return Fail(TEXT("Actual Saved directory is outside the requested smoke sandbox"));
            if (UGameplayStatics::GetCurrentLevelName(W, true) != TEXT("L_Greybox")
                || !Cast<AGreyGameMode>(W->GetAuthGameMode()) || !GI || !GI->Meta)
                return Fail(TEXT("Expected L_Greybox with GreyGameMode and GreyGameInstance"));
            if (!Player || !Player->HasActorBegunPlay() || !Player->GetController()) return false;
            if (!Check(VitalsOK(Player), TEXT("TC1: player/vitals did not initialize to 100,100,100"))) return true;
            Test->AddInfo(TEXT("TC1 PASS: possessed AGreyPlayer and initialized SurvivalVitals"));
            AGreyGate* FirstGate = FindAtX<AGreyGate>(W, 1100.f);
            ASwitchMechanism* FirstSwitch = FindAtX<ASwitchMechanism>(W, 430.f);
            if (!FirstGate || !FirstSwitch) return Fail(TEXT("Generated gate 1 / switch 1 missing"));
            bRestart = FParse::Param(FCommandLine::Get(), TEXT("ThresholdSmokeRestart"));
            if (bRestart)
            {
                if (!Check(FPaths::FileExists(FPaths::Combine(Root, TEXT("Fresh.ok"))),
                        TEXT("Restart check requires a successful fresh-process run"))
                    || !VerifyMeta(GI->Meta.Get(), 1, 20264) || !VerifyDisk(1, 20264)
                    || !Check(GI->GetRunSeed() == 20264 && GI->GetRunNumber() == 2,
                        TEXT("Restart did not initialize saved seed/run number"))
                    || !Check(IsOpen(FirstGate) && FirstSwitch->State == EPuzzleState::Ready,
                        TEXT("Restart must apply saved shortcut without retaining switch state"))) return true;
                Test->AddInfo(TEXT("RESTART PASS: new GameInstance loaded shortcuts/blueprints from disk"));
                if (VerifyTransientReset(W)) Receipt(TEXT("Restart.ok"));
                return true;
            }
            if (!Check(!UGameplayStatics::DoesSaveGameExist(Slot, 0)
                    && GI->Meta->Shortcuts.IsEmpty() && GI->Meta->Blueprints.IsEmpty()
                    && GI->Meta->Knowledge.IsEmpty() && GI->Meta->RunsCompleted == 0
                    && GI->Meta->Victories == 0 && GI->GetRunSeed() == 12345,
                    TEXT("Fresh smoke test requires an empty sandbox"))
                || !Check(!FirstGate->bOpen && FirstGate->Barrier
                    && FirstGate->Barrier->GetCollisionEnabled() != ECollisionEnabled::NoCollision
                    && FirstSwitch->State == EPuzzleState::Ready
                    && FMath::IsNearlyEqual(FirstSwitch->EnergyCost, 12.f),
                    TEXT("TC2: first switch/gate must start ready/closed with 12 energy cost"))) return true;

            // Position and aim the player, then exercise the production camera trace
            // and TryInteract entry point. This does not synthesize keyboard input.
            Player->SetActorLocation(FirstSwitch->GetActorLocation() + FVector(-180, 0, 23),
                false, nullptr, ETeleportType::TeleportPhysics);
            APlayerController* PC = Cast<APlayerController>(Player->GetController());
            if (!PC || !Player->Camera) return Fail(TEXT("Player camera/controller missing"));
            const FRotator Aim = (FirstSwitch->GetActorLocation() - Player->Camera->GetComponentLocation()).Rotation();
            PC->SetControlRotation(Aim);
            Player->Camera->SetWorldRotation(Aim);
            if (!Check(Player->FindInteractable() == FirstSwitch,
                    TEXT("TC2: camera raycast did not hit first switch"))) return true;
            const float EnergyBefore = Player->Vitals->Energy;
            SwitchStarted = FPlatformTime::Seconds();
            Player->TryInteract();
            if (!Check(FirstSwitch->IsTriggered()
                    && FMath::IsNearlyEqual(Player->Vitals->Energy, EnergyBefore - 12.f, 0.01f),
                    TEXT("TC2: switch interaction did not trigger/spend 12 energy"))) return true;
            OriginalWorld = W;
            OriginalPlayer = Player;
            Gate = FirstGate;
            Step = EStep::Gate;
            Deadline = SwitchStarted + 2.0;
            // Observe synchronous opening now, rather than penalizing a later slow tick.
            if (!IsOpen(FirstGate)) return false;
        }
        if (Step == EStep::Gate)
        {
            if (FPlatformTime::Seconds() > Deadline) return Fail(TEXT("TC2: gate missed 2-second deadline"));
            if (!IsOpen(Gate.Get())) return false;
            Test->AddInfo(TEXT("TC2 PASS: switch opened gate with visibility/collision disabled within 2s"));
            // Exercise real production persistence, not a test-owned SaveGame object.
            if (!Player || !GI) return Fail(TEXT("TC3: player or GameInstance disappeared"));
            if (!Check(GI->UnlockShortcut(Shortcut) && GI->UnlockBlueprint(Blueprint),
                    TEXT("TC3: could not create permanent unlock fixture")) || !VerifyDisk(0, 12345)) return true;
            // Restore only spent energy. Oxygen death must come from the normal tick
            // -> OnDied -> AGreyGameMode::EndRun(false) -> delayed OpenLevel chain.
            Player->Vitals->Restore(100.f, 0.f, 0.f);
            Player->Vitals->AddExposure(10000.f, 0.f);
            Step = EStep::Death;
            Deadline = FPlatformTime::Seconds() + 5.0;
            return false;
        }
        if (Step == EStep::Death)
        {
            AGreyPlayer* Old = OriginalPlayer.Get();
            if (!Old) return Fail(TEXT("TC3: player disappeared before oxygen death was observed"));
            if (!Old->Vitals->IsDead()) return false;
            if (!Check(Old->Vitals->Oxygen <= 0.f && Old->Vitals->Energy > 0.f && Old->Vitals->Warmth > 0.f,
                    TEXT("TC3: death was not caused by oxygen reaching zero"))) return true;
            Step = EStep::Reload;
            Deadline = FPlatformTime::Seconds() + 30.0;
            return false;
        }
        if (W == OriginalWorld.Get()) return false;
        if (!Player || !Player->HasActorBegunPlay() || !Player->GetController()) return false;
        if (!Check(UGameplayStatics::GetCurrentLevelName(W, true) == TEXT("L_Greybox")
                && Cast<AGreyGameMode>(W->GetAuthGameMode())
                && Player != OriginalPlayer.Get() && VitalsOK(Player),
                TEXT("TC3: new map/player/vitals initialization incorrect"))) return true;
        if (!GI) return Fail(TEXT("TC3: reloaded GameInstance missing"));
        if (!VerifyMeta(GI->Meta.Get(), 1, 20264) || !VerifyDisk(1, 20264)
            || !Check(GI->GetRunSeed() == 20264 && GI->GetRunNumber() == 2,
                TEXT("TC3: death must advance seed and run number"))) return true;
        const AGreyGate* ReloadedGate = FindAtX<AGreyGate>(W, 1100.f);
        const ASwitchMechanism* ReloadedSwitch = FindAtX<ASwitchMechanism>(W, 430.f);
        if (!Check(IsOpen(ReloadedGate) && ReloadedSwitch && ReloadedSwitch->State == EPuzzleState::Ready,
                TEXT("TC3: permanent shortcut not applied or transient switch progress retained"))) return true;
        Test->AddInfo(TEXT("TC3 PASS: oxygen death reloaded map; disk and applied shortcuts/blueprints retained"));
        if (VerifyTransientReset(W)) Receipt(TEXT("Fresh.ok"));
        return true;
    }
};
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FThresholdGameLoop, "ThresholdRun.Smoke.GameLoop",
    EAutomationTestFlags::ClientContext | EAutomationTestFlags::EngineFilter)
bool FThresholdGameLoop::RunTest(const FString& Parameters)
{
    ADD_LATENT_AUTOMATION_COMMAND(ThresholdSmoke::FGameLoop(this));
    return true;
}
#endif

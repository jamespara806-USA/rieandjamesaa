# Editor setup, build, and reproducible smoke test

## Prerequisites

- UE 5.8 installed; Visual Studio 2022 with Game development with C++ and supported Windows SDK; enough disk space for Unreal compilation.
- `ThresholdRun.uproject` at the project root next to `Source` and `Config`. Do **not** paste these C++ files into an existing project with a different module name unless you update all `THRESHOLDRUN_API`, paths and build targets.
- Enhanced Input plugin enabled (already declared in `.uproject`). The code creates its own mapping actions and mapping context in `AGreyPlayer::SetupPlayerInputComponent`—no Content Browser input assets are necessary.

## Concrete editor steps

1. Extract ZIP to a normal development folder without special permissions (e.g. `C:\UnrealProjects\ThresholdRun\`).
2. Right-click the `.uproject` → Generate Visual Studio project files. If the context menu is missing, use Epic's UnrealVersionSelector or open the project in the Launcher.
3. Build `ThresholdRunEditor` for **Development Editor / Win64** from Visual Studio. Alternatively open the `.uproject` and agree to rebuild missing modules. Resolve C++ compiler errors before running.
4. Launch editor. Check **Edit → Plugins → Enhanced Input**. Restart the editor only if you changed plugin status.
5. File → New Level → **Empty Level**. Save as **`Content/Maps/L_Greybox.umap`**.
6. In Place Actors, add a **Player Start**. Select actor → Details → Transform: Location `(0,0,160)`; Rotation `(0,0,0)`. Only one PlayerStart. Do **not** add floor objects; generation is in `BeginPlay`.
7. World Settings → GameMode Override = `GreyGameMode` (if not already inherited from defaults). **Project Settings → Maps & Modes**: startup and default map `L_Greybox`, GameMode `GreyGameMode`, GameInstance `GreyGameInstance` (last is in `.ini`). Save all.
8. **Play → Selected Viewport**, click the viewport, move your mouse. Grey walls and floors appear only in Play. The HUD shows seed / run, health resources, controls and first-hit interact prompt.
9. When finished testing, **Stop**. The generated world will disappear from the editor view; that is normal.

## First-run acceptance checklist

- [ ] Character spawns inside room 1 above a flat grey floor, and cannot walk through its side walls.
- [ ] WASD, mouse-look, Ctrl, Shift, Space work. The mouse is captured, and the Canvas HUD displays `Energy / Oxygen / Warmth`.
- [ ] Interact target appears only when line-of-sight hits the first solid interactable within ~3.1 m. Putting a wall between the camera and switch must prevent a click-through.
- [ ] Stand at the switch in hub 1 around `(430,-240)` and aim at its cube; press E. **Gate 1** at `(1100,0)` becomes invisible/nonblocking.
- [ ] Walk through gate 1 and pick up `PERMANENT SHORTCUT` at `(1575,-360)`; blueprint at `(2140,-420)`. They disappear, and a SaveGame file should be written.
- [ ] Press E on switch 2 `(2520,-265)`, then walk onto the plate `(2580,240)`. **AND relay** opens gate 2. Leaving the plate leaves gate 2 open.
- [ ] Cross hub 3's cold zone. Warmth decreases; warmth pickup `(4340,-360)` restores it.
- [ ] Interact with `EXIT` at `(4870,0)`; level reloads after about 1.5 s, run number increments, seed changes. **Gate 1 starts open** because the shortcut is persisted.
- [ ] Re-enter the cold zone and stay until Warmth reaches 0; death causes a level reload while the shortcut remains.
- [ ] Restart editor: run count, blueprint and learned shortcut still exist in slot `ThresholdRunMeta_v1`.

## Test failure diagnosis

| Symptom | Likely issue | Fix |
|---|---|---|
| Empty world in Play | Wrong GameMode or module not compiled | Check World Settings, Output Log and `GreyWorldBuilder::BeginPlay` |
| Falling through level | Missing PlayerStart, bad spawn Z, builder not spawned | Place PlayerStart `(0,0,160)` and check floor generated at Z top 0 |
| Input ignored / `EnhancedInputComponent` error | Input component class or plugin not enabled | Verify `Config/DefaultInput.ini`, plugin and restart editor |
| Looking at cube but no prompt | Too far, wrong aim, object behind wall | Move to within 310 cm; aim at the solid cube, not its floating text |
| Gate 2 never opens | Plate not triggered, switch unused, or invalid relay inputs | Check switch state then physically stand on plate; inspect `LogicRelay::Configure` |
| Gate 1 already open on first Play | Old save slot contains shortcut | Use a new save slot name in `GreyGameInstance.cpp` for clean testing |
| Level reloads to unexpected place | Unsaved map / missing GameDefaultMap | Save `L_Greybox`, assign Maps & Modes before testing |
| Runtime generated shapes not visible in editor | Expected: builder runs at game BeginPlay | Use Play mode; to author scenes visually, convert to placed BP prefabs |

**Unreal build validation is still required.** Automated checks run outside UE can find missing files and rough syntax mismatches but do not prove Unreal Header Tool compatibility, visual collision placement, Enhanced Input delivery, or Play behavior.

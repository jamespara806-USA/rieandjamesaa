# Available-host verification — 2026-10-17

Executed on Linux in the cloud workspace:

- Original ZIP CRC/integrity check: passed, 44 files.
- Original file preservation: all 44 files remain byte-for-byte unchanged.
- `python Tools/validate_source.py`: passed; 32 C++ source/header files
  including the newly added native automation test. This is a structural check.
- Python AST parsing: passed for both scripts. Unreal Python APIs were not run.
- PowerShell 7.4 parser: all six PowerShell scripts parsed successfully,
  including the single-launcher build wrapper.
- Build launcher host guard: confirmed that Linux is rejected before any build
  is attempted. The CMD launcher and Windows build path remain unexecuted.
- `Tools/Test-VerificationHelpers.ps1`: eight checks passed. Verified acceptance
  of a successful report and rejection of empty discovery, failed, unrun,
  in-process, unrelated, missing and malformed reports. These are runner tests.
- Process wrapper: actual child-process exit 0 accepted; exit 7 rejected with
  the original exit code in the diagnostic.

PowerShell was extracted outside the repository for host-side verification;
its package SHA256 was checked against Microsoft's official HTTPS package
index. Windows PowerShell 5.1 and Windows process behavior were not exercised.

Not executed: UnrealHeaderTool, UnrealBuildTool, Unreal Python map preparation,
Win64 packaging, native automation discovery, TC1/TC2/TC3, application restart
persistence, manual traversal, collision/input acceptance, or profiling.

No `.exe` or `.umap` is included. No gameplay pass or Windows environment
readiness is claimed. Run the Windows sequence in
`Docs/WINDOWS_BUILD_AND_VERIFICATION.md` on a Windows UE 5.8 machine to obtain
those results. This cloud host has no Unreal Engine, MSVC or Windows SDK.

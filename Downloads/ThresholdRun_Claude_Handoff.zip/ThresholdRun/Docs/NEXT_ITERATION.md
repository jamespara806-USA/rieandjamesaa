# What to build after the first Play succeeds

## Sequence (feature slices, not calendar estimates)

1. **Compile, play, and inspect collisions.** Confirm every room door and wall has solid collision, all pickup raycasts work, and old SaveGames don't contaminate test results. Log generator seed and blueprint actor assignments on run startup.
2. **Introduce BP-prefab modules.** Convert each room into a static `BP_RegionModule` with typed `Entrance/Exit` `USceneComponent` sockets. Write a graph validator so required puzzle inputs always remain upstream of gates. Only then generate shuffled world topology and stream/unload room cells.
3. **Introduce physical puzzle props.** Add a physics crate (`Simulate Physics`) plus pickup/push or a physics-handle system, and allow the plate to count weighted actors. Make sure overlap counts survive physics substep changes and destruction.
4. **Build the first memorable environmental puzzle.** A mirror rotates in increments; reflect a `LineTrace` beam into a power receiver to trigger the same FSM, which opens a gate. Use scripted ray visualization, not GPU light/shadow queries, for the actual puzzle logic.
5. **Expand survival choices.** Add shelter volumes, oxygen refill stations, hazard telegraphing, and a per-run resource budget. Tuning must make a skilled player capable of finishing without having to die for permanent rewards.
6. **Persistence hardening.** Expose profile slots and save version migration, automatic backups and error UI. `SaveGameToSlot` in this prototype is synchronous and should move to asynchronous/queued saving if save payload grows.
7. **Visual polish:** BP animation cues, sound cues, checkpoint feedback, authored lore clues, rebindable input assets (`IA_*`, `IMC_*`), mouse sensitivity, gamepad support, UI settings and accessibility.
8. **Testing and scale:** add automation tests for generator invariants, fuzz 1000+ seeds, explicit pathfinding reachability and difficulty validation, Unreal Insights profiling, memory caps and world partition (only when size demands it).

## Suggested go/no-go success criteria

- 10/10 clean runs spawn at the correct position without falling, and both gates behave correctly.
- 10/10 clicks respect the nearest blocking surface and interaction distance.
- 10/10 forced deaths discard local puzzle state but keep the collected shortcut.
- 10/10 victories regenerate the run while keeping blueprint progress.
- Users can understand and finish the three-hub greybox without external instructions after a short introductory overlay. If they cannot, refine affordances and hazards before adding more world size.

# Threshold Run — Unreal Engine 5 C++ / Blueprints Greybox

**Target:** Unreal Engine 5.8 (native C++; single-player; Windows desktop). This is a **source-first UE project** containing a playable loop implemented in code. It deliberately does **not** include a precompiled executable or a binary `.umap` / `.uasset` level; creating and saving one **empty editor level** with a `PlayerStart` is required. No external Marketplace assets.

## The quickest path to first Play

1. Install Unreal Engine 5.8 and Visual Studio 2022 with **Game development with C++** (Windows SDK / MSVC). Extract this ZIP so `ThresholdRun.uproject` is at the project root.
2. Right-click `ThresholdRun.uproject` → **Generate Visual Studio project files**, or double-click it and allow UE to build missing modules. If it prompts for the missing module, build `ThresholdRunEditor` in Visual Studio with Development Editor / Win64 and reopen.
3. In Unreal Editor: **File → New Level → Empty Level**. Save as `Content/Maps/L_Greybox`.
4. Drag a **Player Start** actor into the empty level. Set **Location X=0, Y=0, Z=160**, **Rotation Yaw=0**. **Do not place a ground plane or other world geometry.** It is generated during Play.
5. Under **World Settings → GameMode Override**, choose `GreyGameMode` if necessary. The game mode and game instance are also set globally in `Config/DefaultEngine.ini`.
6. Set **Project Settings → Maps & Modes → Editor Startup Map and Game Default Map** to `L_Greybox`. Save all. Press **Play (Selected Viewport)** and click the viewport to capture the mouse.
7. Expect three linked box rooms and an optional cache room, two gates, floating instruction text, a vitals HUD and an exit. The procedural world only exists *while playing*; it will not appear in the static editor viewport.

If you see only the sky and not a generated room, check that `GreyGameMode` is selected for the level and the module compiled. If controls are unresponsive, verify **Enhanced Input** plugin is enabled and `DefaultInput.ini` is applied. See `Docs/SETUP_AND_SMOKE_TEST.md`.

## Controls

| Input | Action |
|---|---|
| WASD | Walk |
| Mouse | Look |
| Shift (hold) | Sprint (energy drains) |
| Ctrl (tap) | Toggle crouch |
| Space | Jump |
| E | Interact with center-screen target within 310 cm |

## First run walkthrough

1. **Furnace:** Walk from `X=0` toward the first switch around `X=430, Y=-240`. Aim your crosshair at its physical cube and press **E**. Gate at `X=1100` opens.
2. **Floodgate:** Move into hub 2 (`X=2200`), collect the **Permanent Shortcut** pickup around `X=1575,Y=-360`. It permanently bypasses the first gate on future runs. Collect the blueprint around `X=2140,Y=-420`.
3. Activate the second switch around `X=2520,Y=-265`. Step onto the pressure plate around `X=2580,Y=240`. The **AND relay** latches open the second gate at `X=3300`, so leaving the plate won't trap you.
4. **Observatory:** Cross the signed cold zone (warmth drains), collect the warmth pickup around `X=4340,Y=-360` if necessary, interact with the exit at `X=4870,Y=0`.
5. The current level reloads with a different deterministic seed, and the shortcut and blueprint remain saved. For the death case, **remain in the cold zone until Warmth=0**; the level reloads and persistent knowledge remains.

### Project layout

```
ThresholdRun.uproject
Config/
Source/
  ThresholdRun.Target.cs / ThresholdRunEditor.Target.cs
  ThresholdRun/
    ThresholdRun.Build.cs / ThresholdRun.cpp
    Player/GreyPlayer.h,.cpp
    UI/GreyHUD.h,.cpp
    Interaction/PrototypeInteractable.h
    Survival/SurvivalVitals.h,.cpp / ExposureZone.h,.cpp
    Puzzles/PuzzleMechanism.h,.cpp / SwitchMechanism / PressurePlate
            LogicRelay / GreyGate
    Progression/GreyGameInstance / GreyMetaSave / GreyGameMode
                GreyPickup / GreyExit
    World/GreyWorldBuilder.h,.cpp
Docs/
  ARCHITECTURE.md
  SETUP_AND_SMOKE_TEST.md
  BLUEPRINT_WORKFLOW.md
  NEXT_ITERATION.md
```

## Included vs. not included

**Included in source:** first-person character with native Enhanced Input actions (no IA/IMC assets required), first-hit visibility raycast interface, vitals and exposure, puzzle states/delegates, player-operated pressure plate, logical AND relay, latched doors, in-memory per-run reset, SaveGame permanent unlocks, three-region native block geometry, a seeded optional side cache, basic Canvas HUD.

**Not included:** compiled UE5 binary; binary map or Blueprint assets; production-grade map streaming/landscape/terrain; sound; animations; physics-object pressure plate; advanced inventory/crafting; save migration; real solvability solver; replicated multiplayer. Generated geometry is intentionally basic. The engine must still compile and playtest the provided code.

**Source API references:** Epic docs for Enhanced Input, interfaces and save games:
- https://dev.epicgames.com/documentation/en-us/unreal-engine/enhanced-input-in-unreal-engine
- https://dev.epicgames.com/documentation/en-us/unreal-engine/interfaces-in-unreal-engine
- https://dev.epicgames.com/documentation/en-us/unreal-engine/saving-and-loading-your-game-in-unreal-engine
